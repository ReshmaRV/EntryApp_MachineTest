package com.reshma.machinetest_entryapp.localdb

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.reshma.machinetest_entryapp.localdb.entity.DatesConverter

import com.reshma.machinetest_entryapp.localdb.entity.GenreIdsConverter
import com.reshma.machinetest_entryapp.localdb.entity.MovieConverter
import com.reshma.machinetest_entryapp.localdb.entity.MovieListEntity

@Database(
    entities = [MovieListEntity::class],
    version = 1,
    exportSchema = false
)
@TypeConverters(GenreIdsConverter::class,DatesConverter::class, MovieConverter::class)
abstract class MachineTestEntryAppDatabase : RoomDatabase() {
    abstract fun machineTestDao(): MachineTestEntryAppDao
}
