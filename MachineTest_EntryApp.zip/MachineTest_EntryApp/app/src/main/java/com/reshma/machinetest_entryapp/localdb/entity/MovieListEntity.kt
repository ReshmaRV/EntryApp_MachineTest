package com.reshma.machinetest_entryapp.localdb.entity

import android.os.Parcelable
import androidx.room.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.android.parcel.Parcelize

@Parcelize
@Entity(tableName = "movie_table")
data class MovieListEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "movieId")
    var movieId: Int? = null,



   @TypeConverters(DatesConverter::class)
   // @Embedded
    @ColumnInfo(name = "dates")
    var dates: Dates? = null,

    @ColumnInfo(name = "page")
    var page: Int? = null,



    @TypeConverters(MovieConverter::class)
    @ColumnInfo(name = "results")
    //@Embedded
    var results: List<Movie>? =null,

    @ColumnInfo(name = "total_pages")
    var total_pages: Int? = null,

    @ColumnInfo(name = "total_results")
    var total_results: Int? = null
):Parcelable
/*@TypeConverter
fun fromString(value: String?): List<String> {
    val listType = object :
        TypeToken<ArrayList<String?>?>() {}.type
    return Gson().fromJson(value, listType)
}

@TypeConverter
fun fromList(list: List<String?>?): String {
    val gson = Gson()
    return gson.toJson(list)
}*/

/*class MovieConverter {
    @TypeConverter
    fun toDates(json: String): List<Movie> {
        val type = object : TypeToken<List<Movie>>() {}.type
        return Gson().fromJson(json, type)
    }

    @TypeConverter
    fun toJson(torrent: List<Movie>): String {
        val type = object : TypeToken<List<Movie>>() {}.type
        return Gson().toJson(torrent, type)
    }*/

