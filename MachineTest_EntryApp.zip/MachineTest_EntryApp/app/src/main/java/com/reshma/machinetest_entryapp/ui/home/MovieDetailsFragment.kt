package com.reshma.machinetest_entryapp.ui.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.bumptech.glide.Glide
import com.reshma.machinetest_entryapp.R
import com.reshma.machinetest_entryapp.databinding.FragmentMovieDetailsBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MovieDetailsFragment : Fragment() {

    private var _binding: FragmentMovieDetailsBinding? = null
    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private val args: MovieDetailsFragmentArgs by navArgs()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentMovieDetailsBinding.inflate(inflater, container, false)
        setUiData()
        binding.ivBack.setOnClickListener {
            findNavController().navigateUp()

        }
        return binding.root

    }
    private fun setUiData() {
        args.movie.let {movie->
            binding.tvtitle.text = "Name: ${movie.title}"
            binding.tvDescription.text = "Release Date: ${movie.release_date}"

            binding.ivMovieImage.let {
                Glide.with(requireContext()).load("https://image.tmdb.org/t/p/w500/${movie.poster_path}")
                    .centerCrop()
                    .into(it)
            }
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}