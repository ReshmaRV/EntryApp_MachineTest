package com.reshma.machinetest_entryapp.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.reshma.machinetest_entryapp.remote.repo.Repository
import com.reshma.machinetest_entryapp.remote.response.MovieResult

import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(private val repository: Repository) : ViewModel() {

    private val _categoryList = MutableStateFlow<List<MovieResult>>(listOf())
    val categoryList = _categoryList.asStateFlow()

    //get Movie List from repo
    init {
        viewModelScope.launch {
            repository.getMovieList().collect {
                val mappedList = it?.map { movie ->
                    MovieResult(
                        movie.adult,
                        movie.backdrop_path,
                        movie.genre_ids,
                        movie.id,
                        movie.original_language,
                        movie.original_title,
                        movie.overview,
                        movie.popularity,
                        movie.poster_path,
                        movie.release_date,
                        movie.original_title,
                        movie.video,
                        movie.vote_average,
                        movie.vote_count
                    )
                }
                if (mappedList != null) {
                    _categoryList.value = mappedList
                }
            }

        }
    }
}

