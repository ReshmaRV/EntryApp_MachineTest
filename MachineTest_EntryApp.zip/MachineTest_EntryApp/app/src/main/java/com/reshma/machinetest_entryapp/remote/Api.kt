package com.reshma.machinetest_entryapp.remote


import com.reshma.machinetest_entryapp.remote.response.MovieListResponse
import com.reshma.machinetest_entryapp.utils.network.ApiResponse
import kotlinx.coroutines.flow.Flow
import retrofit2.http.GET
import retrofit2.http.Query

interface Api {
    @GET("movie/now_playing")
    fun getMovieList(@Query("api_key") api_key :String,
                @Query("page") page :String
    ): Flow<ApiResponse<MovieListResponse>>
}
