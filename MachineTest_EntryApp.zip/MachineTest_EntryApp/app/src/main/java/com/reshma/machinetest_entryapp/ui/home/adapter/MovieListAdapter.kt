package com.reshma.machinetest_entryapp.ui.home.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView

import com.bumptech.glide.Glide
import com.reshma.machinetest_entryapp.databinding.MovieItemListBinding
import com.reshma.machinetest_entryapp.remote.response.MovieListResponse
import com.reshma.machinetest_entryapp.remote.response.MovieResult

class MovieListAdapter(
    private val context: Context,
    val onMainItemClicked: (MovieResult?) -> Unit,
    private var list: List<MovieResult>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)
            : ViewHolder {

        val layoutInflater = LayoutInflater.from(parent.context)
        val movieItemListBinding: MovieItemListBinding =
            MovieItemListBinding.inflate(layoutInflater, parent, false)
        return ViewHolder(movieItemListBinding)

    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as ViewHolder).bind(list[position])
        var movie: MovieResult = list[position]
        holder.bind(movie)
    }


    override fun getItemCount(): Int = list.size


    inner class ViewHolder(binding: MovieItemListBinding) :
        RecyclerView.ViewHolder(binding.root) {
        private val binding: MovieItemListBinding = binding
        fun bind(movie: MovieResult): Unit {

            binding.tvName.text = "Name : ${movie.title}"
            binding.tvDescriptions.text = "Release Date :  ${movie.release_date}"

            binding.ivProfileImage?.let {
                Glide.with(context).load("https://image.tmdb.org/t/p/w500/${movie.poster_path}")
                    .centerCrop()
                    .into(it)

            }

            binding.clMovieDetails.setOnClickListener { onMainItemClicked.invoke(movie) }

        }
    }


}