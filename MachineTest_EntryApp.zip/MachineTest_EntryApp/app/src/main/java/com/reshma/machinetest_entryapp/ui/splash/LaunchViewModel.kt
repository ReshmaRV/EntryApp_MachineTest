package com.reshma.machinetest_entryapp.ui.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.cachedIn
import com.reshma.machinetest_entryapp.remote.Api
import com.reshma.machinetest_entryapp.remote.repo.Repository
import com.reshma.machinetest_entryapp.ui.paging.MovieDataSource
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class LaunchViewModel @Inject constructor(private val repository: Repository,private  val api: Api) : ViewModel() {

    val API_KEY="d5e833aaaea874b4acebc40ddcbbee69"
    //Fetch movie list with pager
    val fetchMovieList= Pager(PagingConfig(pageSize = 10)) {
        MovieDataSource(api,repository,API_KEY)
    }.flow.cachedIn(viewModelScope)


}
