package com.reshma.machinetest_entryapp.ui.home

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.viewModels
import androidx.lifecycle.asLiveData
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.reshma.machinetest_entryapp.R
import com.reshma.machinetest_entryapp.databinding.FragmentMovieListBinding
import com.reshma.machinetest_entryapp.remote.response.MovieListResponse
import com.reshma.machinetest_entryapp.remote.response.MovieResult
import com.reshma.machinetest_entryapp.ui.home.adapter.MovieListAdapter
import com.reshma.machinetest_entryapp.utils.ListPaddingDecoration
import com.reshma.machinetest_entryapp.utils.Utils.safeNavigate
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MovieListFragment : Fragment() {
    private var _binding: FragmentMovieListBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    private val viewModel: HomeViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentMovieListBinding.inflate(inflater, container, false)
        setupObservables()
        return binding.root

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupObservables() {
        //get Adapter data
        viewModel.categoryList.asLiveData().observe(viewLifecycleOwner) {
            val adapter = MovieListAdapter(
                requireContext(),
                this::onRecyclerMainItemClicked, it
            )
            binding.rvEmployeeList.layoutManager = LinearLayoutManager(
                context,
                RecyclerView.VERTICAL, false
            )
            binding.rvEmployeeList.addItemDecoration(
                ListPaddingDecoration(
                    requireContext(),
                    5,
                    0
                )
            )
            binding.rvEmployeeList.adapter = adapter
        }

    }

    private fun onRecyclerMainItemClicked(movie: MovieResult?) {
        movie?.let {
            openDetailPage(it)
        }
    }

    //Navigate to individual item
    private fun openDetailPage(
        movie: MovieResult
    ) {
        safeNavigate(
            MovieListFragmentDirections.actionMovieListFragmentToMovieDetailsFragment(movie)
        )
    }

}