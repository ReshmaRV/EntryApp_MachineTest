package com.reshma.machinetest_entryapp.di

import android.content.Context
import androidx.room.Room
import com.reshma.machinetest_entryapp.localdb.MachineTestEntryAppDao
import com.reshma.machinetest_entryapp.localdb.MachineTestEntryAppDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
class DataBaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MachineTestEntryAppDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            MachineTestEntryAppDatabase::class.java,
            "machine_test_database.db"
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides
    @Singleton
    fun provideDao(database: MachineTestEntryAppDatabase): MachineTestEntryAppDao {
        return database.machineTestDao()
    }
}
