package com.reshma.machinetest_entryapp.remote.response

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class MovieListResponse(
    @SerialName("dates")
    val dates: Dates,
    @SerialName("page")
    val page: Int,
    @SerialName("results")
    val results: List<MovieResult>,
    @SerialName("total_pages")
    val total_pages: Int,
    @SerialName("total_results")
    val total_results: Int
) : Parcelable

@Parcelize
@Serializable
data class Dates(
    @SerialName("maximum")
    val maximum: String,
    @SerialName("minimum")
    val minimum: String
) : Parcelable

@Parcelize
@Serializable
data class MovieResult(
    @SerialName("adult")
    val adult: Boolean?=null,
    @SerialName("backdrop_path")
    val backdrop_path: String?=null,
    @SerialName("genre_ids")
    val genre_ids: List<Int>?= listOf(),
    @SerialName("id")
    val id: Int?=null,
    @SerialName("original_language")
    val original_language: String?=null,
    @SerialName("original_title")
    val original_title: String?=null,
    @SerialName("overview")
    val overview: String?=null,
    @SerialName("popularity")
    val popularity: Double?=null,
    @SerialName("poster_path")
    val poster_path: String?=null,
    @SerialName("release_date")
    val release_date: String?=null,
    @SerialName("title")
    val title: String?=null,
    @SerialName("video")
    val video: Boolean?=null,
    @SerialName("vote_average")
    val vote_average: Double?=null,
    @SerialName("vote_count")
    val vote_count: Int?=null
) : Parcelable