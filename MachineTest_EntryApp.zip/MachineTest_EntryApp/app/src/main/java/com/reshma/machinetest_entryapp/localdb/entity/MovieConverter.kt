package com.reshma.machinetest_entryapp.localdb.entity

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

open class MovieConverter {
    @TypeConverter
    fun toDates(json: String): List<Movie> {
        val type = object : TypeToken<List<Movie>>() {}.type
        return Gson().fromJson(json, type)
    }

    @TypeConverter
    fun toJson(torrent: List<Movie>): String {
        val type = object : TypeToken<List<Movie>>() {}.type
        return Gson().toJson(torrent, type)
    }
}