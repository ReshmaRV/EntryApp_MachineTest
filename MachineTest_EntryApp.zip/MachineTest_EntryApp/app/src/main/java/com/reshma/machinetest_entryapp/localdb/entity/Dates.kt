package com.reshma.machinetest_entryapp.localdb.entity


import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import kotlinx.android.parcel.Parcelize

@Parcelize

data class Dates(
    @ColumnInfo(name = "maximum")
    var maximum: String?=null,

    @ColumnInfo(name = "minimum")
    var minimum: String?=null
):Parcelable
