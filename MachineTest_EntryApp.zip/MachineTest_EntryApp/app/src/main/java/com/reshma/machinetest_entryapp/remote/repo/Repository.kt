package com.reshma.machinetest_entryapp.remote.repo


import com.reshma.machinetest_entryapp.remote.Api
import com.reshma.machinetest_entryapp.localdb.MachineTestEntryAppDao
import com.reshma.machinetest_entryapp.localdb.entity.Movie
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Repository @Inject constructor(private val api: Api,
                                     private val dao: MachineTestEntryAppDao
) {
    //fetch movie list from API network call
    fun fetchMovieList(api_key :String,count :String) = api.getMovieList(api_key,count)

    //Insert to local DB ROOM
    suspend fun insertData(data: List<Movie>) = dao.insertData(data)

    //fetch movie list from local DB ROOM
    fun getMovieList() = dao.getMovieList(1)


}
