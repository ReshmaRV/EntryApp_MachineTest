package com.reshma.machinetest_entryapp.localdb.entity

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

open class DatesConverter {

    @TypeConverter
    fun toGson(value: String): Dates? {
        val listType = object : TypeToken<Dates>() {}.type
        return Gson().fromJson<Dates>(value, listType)
    }

    @TypeConverter
    fun fromList(list: Dates?): String {
        val gson = Gson()
        return gson.toJson(list)
    }


}